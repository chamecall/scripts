## Unit Tests

To run the unittests, do:
```
python -m unittest discover -v -s tests
```

There are also end-to-end inference & training tests, in [dev/run_*_tests.sh](../dev).
